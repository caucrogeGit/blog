<?php

namespace App\Model;

class SearchData
{
    public string $search = '';
}



